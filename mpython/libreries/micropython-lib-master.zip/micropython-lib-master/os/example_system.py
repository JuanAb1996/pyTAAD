import os

print("Executing ls -l:")
os.system("ls -l")
