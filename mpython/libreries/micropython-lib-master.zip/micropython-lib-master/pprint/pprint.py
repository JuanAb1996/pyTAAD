def pformat(obj):
    return repr(obj)

def pprint(obj):
    print(repr(obj))
